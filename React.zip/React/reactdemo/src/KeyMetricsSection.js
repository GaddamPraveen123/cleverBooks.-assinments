import React from 'react';
import './KeyMetricsSection.css';

const KeyMetricsSection = () => {
    return (
        <section className="key-metrics">
            <h2>Why Choose CleverBooks?</h2>
            <div className="metrics">
                <div className="metric">
                    <i className="icon-example"></i>
                    <p>Metric 1</p>
                </div>
                <div className="metric">
                    <i className="icon-example"></i>
                    <p>Metric 2</p>
                </div>
                <div className="metric">
                    <i className="icon-example"></i>
                    <p>Metric 3</p>
                </div>
            </div>
        </section>
    );
}

export default KeyMetricsSection;
