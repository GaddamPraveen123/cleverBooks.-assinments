import React from 'react';
import './KeyProblemsSection.css';

const KeyProblemsSection = () => {
    return (
        <section className="key-problems">
            <h2>Key Problems Solved by CleverBooks</h2>
            <p>Discover the issues we target and how we solve them.</p>
        </section>
    );
}

export default KeyProblemsSection;
