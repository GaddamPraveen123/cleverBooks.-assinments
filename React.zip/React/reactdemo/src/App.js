import React from 'react';
import HeroSection from './HeroSection';
import KeyProblemsSection from './KeyProblemsSection';
import KeyMetricsSection from './KeyMetricsSection';
import ReviewsSection from './ReviewsSection';
import ProblemTargetSection from './ProblemTargetSection';
import CTASection from './CTASection';
import FooterSection from './FooterSection';
import SignUpForm from './SignUpForm';
import './App.css';

const App = () => {
    return (
        <div className="App">
            <HeroSection />
            <KeyProblemsSection />
            <KeyMetricsSection />
            <ReviewsSection />
            <ProblemTargetSection />
            <CTASection />
            <FooterSection />
            <SignUpForm />
        </div>
    );
}

export default App;
