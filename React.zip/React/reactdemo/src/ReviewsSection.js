import React from 'react';
import './ReviewsSection.css';

const ReviewsSection = () => {
    return (
        <section className="reviews">
            <h2>Customer Reviews</h2>
            <div className="review">
                <p>"CleverBooks has transformed our business!"</p>
                <p>- Happy Customer</p>
            </div>
            <div className="review">
                <p>"Exceptional service and quality."</p>
                <p>- Satisfied Client</p>
            </div>
        </section>
    );
}

export default ReviewsSection;
