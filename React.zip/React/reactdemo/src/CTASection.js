import React from 'react';
import './CTASection.css';

const CTASection = () => {
    return (
        <section className="cta">
            <h2>Grow faster than you think with CleverBooks</h2>
            <button>Sign Up Now</button>
        </section>
    );
}

export default CTASection;
