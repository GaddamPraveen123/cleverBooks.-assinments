import React, { useState } from 'react';
import './SignUpForm.css';

const SignUpForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        age: '',
        email: '',
        dob: ''
    });

    const [errors, setErrors] = useState({});
    const [submitted, setSubmitted] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const validate = () => {
        let formErrors = {};
        if (!formData.name) formErrors.name = 'Name is required';
        if (!formData.age) formErrors.age = 'Age is required';
        if (!formData.email) {
            formErrors.email = 'Email is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            formErrors.email = 'Email address is invalid';
        }
        if (!formData.dob) formErrors.dob = 'Date of Birth is required';
        return formErrors;
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const formErrors = validate();
        if (Object.keys(formErrors).length === 0) {
            console.log(formData);
            setSubmitted(true);
        } else {
            setErrors(formErrors);
        }
    };

    return (
        <div>
            {submitted ? (
                <div className="confirmation-message">
                    <p>Thank you for signing up!</p>
                </div>
            ) : (
                <form className="sign-up-form" onSubmit={handleSubmit}>
                    <label htmlFor="name">Name</label>
                    <input
                        id="name"
                        name="name"
                        type="text"
                        value={formData.name}
                        onChange={handleChange}
                    />
                    {errors.name && <div className="error-message">{errors.name}</div>}

                    <label htmlFor="age">Age</label>
                    <input
                        id="age"
                        name="age"
                        type="number"
                        value={formData.age}
                        onChange={handleChange}
                    />
                    {errors.age && <div className="error-message">{errors.age}</div>}

                    <label htmlFor="email">Email</label>
                    <input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                    />
                    {errors.email && <div className="error-message">{errors.email}</div>}

                    <label htmlFor="dob">Date of Birth</label>
                    <input
                        id="dob"
                        name="dob"
                        type="date"
                        value={formData.dob}
                        onChange={handleChange}
                    />
                    {errors.dob && <div className="error-message">{errors.dob}</div>}

                    <button type="submit">Submit</button>
                </form>
            )}
        </div>
    );
};

export default SignUpForm;
