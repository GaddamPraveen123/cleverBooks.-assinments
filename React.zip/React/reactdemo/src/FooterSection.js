import React from 'react';
import './FooterSection.css';

const FooterSection = () => {
    return (
        <footer className="footer">
            <p>© 2024 CleverBooks, All rights reserved.</p>
            <p>123 CleverBooks St, Bookland, BK 12345</p>
        </footer>
    );
}

export default FooterSection;
