import React from 'react';
import './ProblemTargetSection.css';

const ProblemTargetSection = () => {
    return (
        <section className="problem-target">
            <h2>Features of CleverBooks</h2>
            <div className="tabs">
                <div className="tab">
                    <h3>Feature 1</h3>
                    <p>Explanation of feature 1.</p>
                </div>
                <div className="tab">
                    <h3>Feature 2</h3>
                    <p>Explanation of feature 2.</p>
                </div>
                <div className="tab">
                    <h3>Feature 3</h3>
                    <p>Explanation of feature 3.</p>
                </div>
            </div>
        </section>
    );
}

export default ProblemTargetSection;
